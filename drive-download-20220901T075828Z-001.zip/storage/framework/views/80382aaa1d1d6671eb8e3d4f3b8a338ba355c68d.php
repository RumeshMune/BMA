<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    

</head>

<body>
<img src="assets\images\BMA Cert\ <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    

</head>

<body>
<img src="assets\images\BMA Cert\ <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    

</head>

<body>
<img src="assets\images\BMA Cert\ABLH9596VO.jpg" alt="">
<!-- <form  action="<?php echo e(url('uploadproduct')); ?>" method="post" enctype ="multypart/form_data"> 
    <?php echo csrf_field(); ?>  
<input type="text" name="name" class="form-control" placeholder="uploadproduct" />
<input type="file" name="file" />
<input type="submit" />
<input type="submit" name="submit" role="button" value="Search">

<img src="<?php echo e(url('uploadproduct')); ?>" alt="">
<input type="submit" name="submit" role="button" value="Search">
</form>
<form  action="home"img src="<?php echo e(url('uploadproduct')); ?>" method="post" enctype ="multypart/form_data">  
<input type="text" name="name" class="form-control" placeholder="uploadproduct" />
<input type="file" name="file" />
<input type="submit" />
<input type="submit" name="submit" role="button" value="Search"> -->
</body>
</html>.jpg" alt="">
<!-- <form  action="<?php echo e(url('uploadproduct')); ?>" method="post" enctype ="multypart/form_data"> 
    <?php echo csrf_field(); ?>  
<input type="text" name="name" class="form-control" placeholder="uploadproduct" />
<input type="file" name="file" />
<input type="submit" />
<input type="submit" name="submit" role="button" value="Search">

<img src="<?php echo e(url('uploadproduct')); ?>" alt="">
<input type="submit" name="submit" role="button" value="Search">
</form>
<form  action="home"img src="<?php echo e(url('uploadproduct')); ?>" method="post" enctype ="multypart/form_data">  
<input type="text" name="name" class="form-control" placeholder="uploadproduct" />
<input type="file" name="file" />
<input type="submit" />
<input type="submit" name="submit" role="button" value="Search"> -->
</body>
</html>.jpg" alt="">
<!-- <form  action="<?php echo e(url('uploadproduct')); ?>" method="post" enctype ="multypart/form_data"> 
    <?php echo csrf_field(); ?>  
<input type="text" name="name" class="form-control" placeholder="uploadproduct" />
<input type="file" name="file" />
<input type="submit" />
<input type="submit" name="submit" role="button" value="Search">

<img src="<?php echo e(url('uploadproduct')); ?>" alt="">
<input type="submit" name="submit" role="button" value="Search">
</form>
<form  action="home"img src="<?php echo e(url('uploadproduct')); ?>" method="post" enctype ="multypart/form_data">  
<input type="text" name="name" class="form-control" placeholder="uploadproduct" />
<input type="file" name="file" />
<input type="submit" />
<input type="submit" name="submit" role="button" value="Search"> -->
</body>
</html><?php /**PATH C:\Users\Sumedha Electronics\Desktop\New folder (3)\custom_login\resources\views/ABLH9596VO.blade.php ENDPATH**/ ?>