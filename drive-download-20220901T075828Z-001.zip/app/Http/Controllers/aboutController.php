<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class aboutController extends Controller
{
    public function about(){
        return view('about');
    }
    public function aipm4385aa(){
        return view('aipm4385aa');
    }
    public function ablh9596vo(){
        return view('ablh9596vo');
    }
    public function biyr4519ri(){
        return view('biyr4519ri');
    }
    public function bnkg4533xp(){
        return view('bnkg4533xp');
    }
    public function cnsm6207jn(){
        return view('cnsm6207jn');
    }
    public function dbtj4425bb(){
        return view('dbtj4425bb');
    }
    public function dnzg8401wf(){
        return view('dnzg8401wf');
    }
   
    public function fcog8697ac(){
        return view('fcog8697ac');
    }
    public function gufd8440mp(){
        return view('gufd8440mp');
    }
    public function hsgr4103rk(){
        return view('hsgr4103rk');
    }
    public function iqbe5558uc(){
        return view('iqbe5558uc');
    }
    public function jhvk7316gs(){
        return view('jhvk7316gs');
    }
    public function jqvg2382ba(){
        return view('jqvg2382ba');
    }

     public function kfdf5011lx(){
        return view('kfdf5011lx');
    }
    public function lmnb8974bp(){
        return view('lmnb8974bp');
    }
    public function mjub7013vj(){
        return view('mjub7013vj');
    }
    public function mpie8973mg(){
        return view('mpie8973mg');
    }
    public function mvop2246hy(){
        return view('mvop2246hy');
    }


    public function nbfp8229ha(){
    return view('nbfp8229ha');
    }

    public function otaa2493nv(){
    return view('otaa2493nv');
    }
    
    public function oxno4195iv(){
        return view('oxno4195iv');
    }
    
    public function phnr8859rt(){
        return view('phnr8859rt');
    }

  
    public function pjlf0355jt(){
        return view('pjlf0355jt');
    }
    
    public function qlzz5607xr(){
        return view('qlzz5607xr');
    }
    
    public function qrml4924sh(){
        return view('qrml4924sh');
    }
    public function wxqf4327ek(){
        return view('wxqf4327ek');
    }

    public function wkca1195wm(){
        return view('wkca1195wm');
    }
    public function whqe8709mh(){
        return view('whqe8709mh');
    }
    public function wcnj5535co(){
        return view('wcnj5535co');
    }
    public function vwbq4379mt(){
        return view('vwbq4379mt');
    }
    public function uxpe4911mg(){
        return view('uxpe4911mg');
    }
    public function tszn9610xh(){
        return view('tszn9610xh');
    }
    public function smzz7475hk(){
        return view('smzz7475hk');
    }
    public function scfl0806wj(){
        return view('scfl0806wj');
    } 
    public function ZXNW3364HL(){
        return view('ZXNW3364HL');
    } 
    public function zigr3018fh(){
        return view('zigr3018fh');
    }
}
















