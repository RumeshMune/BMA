<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\cetificate;

class pagController extends Controller
{
    //
   
    public function ABLH9596VO(){
        return view('ABLH9596VO');
    }
    


   
   

}
