<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class imageController extends Controller
{
    //
    public function ABLH9596VO(){
        return view('ABLH9596VO');
    }
    
}
