


        
       

   <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    

</head>

<body>
<img src="assets\images\BMA Cert\.$view_slug.jpg" alt="">
<!-- <form  action="{{url('uploadproduct')}}" method="post" enctype ="multypart/form_data"> 
    @csrf  
<input type="text" name="name" class="form-control" placeholder="uploadproduct" />
<input type="file" name="file" />
<input type="submit" />
<input type="submit" name="submit" role="button" value="Search">

<img src="{{url('uploadproduct')}}" alt="">
<input type="submit" name="submit" role="button" value="Search">
</form>
<form  action="home"img src="{{url('uploadproduct')}}" method="post" enctype ="multypart/form_data">  
<input type="text" name="name" class="form-control" placeholder="uploadproduct" />
<input type="file" name="file" />
<input type="submit" />
<input type="submit" name="submit" role="button" value="Search"> -->
</body>
</html>