@extends('main')

@section('content')

<div class="card">
	<div class="card-header">Dashboard</div>
	<div class="card-body">
		
		
	</div>
</div>
<a class="btn btn_success" href="{{url('/uploadpage')}}" >upload ceti </a>

@endsection('content')